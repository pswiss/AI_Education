const detailRange = document.getElementById("detailRange");
const evidenceText = document.getElementById("evidenceText");
const outcomeText = document.getElementById("outcomeText");
const complexityTag = document.getElementById("complexityTag");
const biasVarianceTag = document.getElementById("biasVarianceTag");
const generalizationTag = document.getElementById("generalizationTag");

const suspectCards = Array.from(document.querySelectorAll(".game-suspect"));
const suspectTraitTexts = Array.from(document.querySelectorAll(".trait-text"));
const confidenceBars = Array.from(document.querySelectorAll(".confidence span"));
const guessResult = document.getElementById("guessResult");

const sketchPortrait = document.getElementById("sketchPortrait");
const sketchSummary = document.getElementById("sketchSummary");
const sketchTagA = document.getElementById("sketchTagA");
const sketchTagB = document.getElementById("sketchTagB");

const sceneButtons = Array.from(document.querySelectorAll(".scene-btn"));
const scenePrev = document.getElementById("scenePrev");
const sceneNext = document.getElementById("sceneNext");

const sceneChip = document.getElementById("sceneChip");
const focusTermTitle = document.getElementById("focusTermTitle");
const focusTermText = document.getElementById("focusTermText");
const focusTermAnalogy = document.getElementById("focusTermAnalogy");

const metricBars = {
  bias: document.getElementById("metricBias"),
  variance: document.getElementById("metricVariance"),
  complexity: document.getElementById("metricComplexity"),
  generalization: document.getElementById("metricGeneralization"),
};

const metricValues = {
  bias: document.getElementById("metricBiasValue"),
  variance: document.getElementById("metricVarianceValue"),
  complexity: document.getElementById("metricComplexityValue"),
  generalization: document.getElementById("metricGeneralizationValue"),
};

const termCards = {
  underfitting: document.getElementById("termUnderfitting"),
  goodfit: document.getElementById("termGoodfit"),
  overfitting: document.getElementById("termOverfitting"),
  prevention: document.getElementById("termPrevention"),
};

const graphVideo = document.getElementById("errorGraphVideo");
const graphVideoStatus = document.getElementById("graphVideoStatus");
const chartMarker = document.getElementById("chartMarker");
const chartMarkerLabel = document.getElementById("chartMarkerLabel");

const GRAPH_LAYOUT = {
  padXRatio: 0.08,
  padYRatio: 0.12,
};

const sceneTargets = [15, 50, 85];
const suspectDescriptors = [
  "Long brown hair, mustard jacket, blue eyes",
  "Buzz cut, red jacket, green eyes, nose ring",
  "Curly brown hair, dark hoodie, amber eyes, neck tattoo",
];
const actualCriminalIndex = 2;

let currentSceneIndex = 1;
let previousStateKey = "";

const states = [
  {
    key: "underfit",
    threshold: [0, 33],
    evidence:
      "Witness report is too broad: 'average height, dark hoodie, neutral face.' The model only has generic clues.",
    complexity: "Low complexity (model too simple)",
    biasVariance: "High bias, low variance",
    generalization: "Poor fit on both training and new data",
    outcome:
      "The detective stops many unrelated people because broad features do not isolate the real criminal.",
    confidence: [61, 58, 63],
    sketch: {
      summary: "The witness sketch is vague. Most suspects look similar against this sketch.",
      tags: ["dark hoodie", "average build"],
    },
    game: {
      prompt: "Arrest one suspect. Then review why broad sketches increase false positives.",
      correct:
        "Correct arrest. Riley is the criminal, but this model state is still risky because the same sketch can match many innocents.",
      wrong:
        "Wrong arrest. Riley is Suspect C. Underfitting makes wrong arrests more likely because the sketch is too generic.",
    },
    markerColor: "#b9b9b9",
    story: {
      chip: "Scene 1: Underfitting",
      focusTitle: "Underfitting means missing useful patterns",
      focusText:
        "The model is too simple, so it cannot capture important clues from the training set. Even old case notes still look confusing.",
      analogy:
        "Detective translation: one vague sketch makes three strangers look equally suspicious.",
      metrics: {
        bias: 89,
        variance: 24,
        complexity: 20,
        generalization: 30,
      },
      terms: {
        underfitting: "Risk is high right now. The feature set is too broad to separate suspects.",
        goodfit: "Not reached yet. The model still needs richer but stable evidence signals.",
        overfitting: "Low risk at this stage because the model is not complex enough to memorize noise.",
        prevention: "Add stronger features and more diverse witness data before increasing complexity.",
      },
    },
  },
  {
    key: "goodfit",
    threshold: [34, 66],
    evidence:
      "Witnesses agree on stable clues: hair pattern, jacket cut, and repeated facial proportions. The model tracks consistent signal.",
    complexity: "Medium complexity (balanced)",
    biasVariance: "Balanced bias and variance",
    generalization: "Strong generalization to unseen suspects",
    outcome:
      "The detective narrows the lineup effectively and identifies the real criminal with higher reliability.",
    confidence: [35, 28, 86],
    sketch: {
      summary: "The sketch captures Riley's stable features clearly enough to separate the lineup without chasing noise.",
      tags: ["curly hair", "neck tattoo"],
    },
    game: {
      prompt: "Arrest one suspect. This is the best operating point for reliable decision-making.",
      correct:
        "Correct arrest. Riley is the criminal. This balanced model uses stable clues that transfer to new scenarios.",
      wrong:
        "Wrong arrest. Riley is Suspect C. Good-fit models still can fail sometimes, but error risk is lowest here.",
    },
    markerColor: "#f6ca3e",
    story: {
      chip: "Scene 2: Good Fit",
      focusTitle: "Balanced model complexity finds real signal",
      focusText:
        "The model keeps only features that repeatedly matter across witnesses. It performs well on training and on new suspect checks.",
      analogy:
        "Detective translation: enough detail to narrow the crowd, not so much detail that tiny changes break the search.",
      metrics: {
        bias: 46,
        variance: 45,
        complexity: 54,
        generalization: 88,
      },
      terms: {
        underfitting: "Risk is reduced because the model now captures key suspect structure.",
        goodfit: "Target state achieved. Features are informative, stable, and transferable to new scenes.",
        overfitting: "Still controlled. The detective has not started chasing random one-off details.",
        prevention: "Validate on unseen witness statements and keep only features with repeat evidence.",
      },
    },
  },
  {
    key: "overfit",
    threshold: [67, 100],
    evidence:
      "Sketch detail is over-specified with noisy clues (exact zipper angle, tiny dust patterns). The model memorizes one scene.",
    complexity: "Very high complexity (model too complex)",
    biasVariance: "Low bias, high variance",
    generalization: "Low real-world reliability",
    outcome:
      "The detective over-trusts fragile details. Performance on new sightings drops, so the criminal is easier to miss.",
    confidence: [8, 5, 11],
    sketch: {
      summary: "The sketch is too detailed and brittle. It records tiny one-off details that do not transfer to new sightings.",
      tags: ["scar angle: 22 deg", "left hoodie string"],
    },
    game: {
      prompt: "Arrest one suspect. Then compare why extreme detail can still produce poor generalization.",
      correct:
        "Correct arrest. Riley is the criminal, but this overfit state is fragile and can fail quickly when conditions change.",
      wrong:
        "Wrong arrest. Riley is Suspect C. Overfitting causes brittle decisions based on accidental details.",
    },
    markerColor: "#f18d2a",
    story: {
      chip: "Scene 3: Overfitting",
      focusTitle: "Overfitting means memorizing noise",
      focusText:
        "The model became too complex and locked onto accidental details from one witness account. Validation performance collapses.",
      analogy:
        "Detective translation: perfect memory of one shoelace angle, zero adaptability in a real city search.",
      metrics: {
        bias: 22,
        variance: 92,
        complexity: 89,
        generalization: 20,
      },
      terms: {
        underfitting: "Not the main problem now; the model is no longer too simple.",
        goodfit: "Lost. The system drifted past useful detail into fragile memorization.",
        overfitting: "Risk is critical. Tiny visual changes invalidate the model's decision rule.",
        prevention: "Apply regularization, prune noisy features, and cross-validate before deployment.",
      },
    },
  },
];

function getState(value) {
  return states.find((state) => value >= state.threshold[0] && value <= state.threshold[1]) || states[1];
}

function getSceneIndexFromValue(value) {
  if (value <= 33) return 0;
  if (value <= 66) return 1;
  return 2;
}

function setSceneButtonState(index) {
  sceneButtons.forEach((button, buttonIndex) => {
    button.classList.toggle("active", buttonIndex === index);
  });
}

function animateSliderTo(target) {
  const start = Number(detailRange.value);
  if (start === target) {
    updateUI(target);
    return;
  }

  const duration = 320;
  let startTime = null;

  function step(timestamp) {
    if (!startTime) startTime = timestamp;
    const elapsed = timestamp - startTime;
    const progress = Math.min(elapsed / duration, 1);
    const eased = 1 - Math.pow(1 - progress, 3);
    const value = Math.round(start + (target - start) * eased);

    detailRange.value = String(value);
    updateUI(value);

    if (progress < 1) {
      window.requestAnimationFrame(step);
    }
  }

  window.requestAnimationFrame(step);
}

function goToScene(index) {
  const clampedIndex = Math.max(0, Math.min(sceneTargets.length - 1, index));
  currentSceneIndex = clampedIndex;
  animateSliderTo(sceneTargets[clampedIndex]);
}

function updateStoryPanel(state) {
  sceneChip.textContent = state.story.chip;
  focusTermTitle.textContent = state.story.focusTitle;
  focusTermText.textContent = state.story.focusText;
  focusTermAnalogy.textContent = state.story.analogy;

  Object.keys(metricBars).forEach((metricKey) => {
    const metricValue = state.story.metrics[metricKey];
    metricBars[metricKey].style.width = `${metricValue}%`;
    metricValues[metricKey].textContent = `${metricValue}%`;
  });

  termCards.underfitting.textContent = state.story.terms.underfitting;
  termCards.goodfit.textContent = state.story.terms.goodfit;
  termCards.overfitting.textContent = state.story.terms.overfitting;
  termCards.prevention.textContent = state.story.terms.prevention;
}

function updateSketchCard(state) {
  sketchSummary.textContent = state.sketch.summary;
  sketchTagA.textContent = state.sketch.tags[0];
  sketchTagB.textContent = state.sketch.tags[1];

  if (state.key === "underfit") {
    sketchPortrait.style.setProperty("--sketch-blur", "2.1px");
    sketchPortrait.style.setProperty("--sketch-tag-opacity", "0.08");
    sketchPortrait.style.setProperty("--sketch-noise", "0.06");
    sketchPortrait.style.setProperty("--sketch-hair-fill", "linear-gradient(180deg, #242424, #111)");
    sketchPortrait.style.setProperty("--sketch-hair-width", "30%");
    sketchPortrait.style.setProperty("--sketch-hair-height", "16%");
    sketchPortrait.style.setProperty("--sketch-hair-top", "14%");
    sketchPortrait.style.setProperty("--sketch-coat-color", "#363636");
    sketchPortrait.style.setProperty("--sketch-eye-color", "#685437");
    sketchPortrait.style.setProperty("--sketch-scar-opacity", "0");
    sketchPortrait.style.setProperty("--sketch-tattoo-opacity", "0");
    sketchPortrait.style.setProperty("--sketch-string-opacity", "0");
  }

  if (state.key === "goodfit") {
    sketchPortrait.style.setProperty("--sketch-blur", "0.55px");
    sketchPortrait.style.setProperty("--sketch-tag-opacity", "0.46");
    sketchPortrait.style.setProperty("--sketch-noise", "0.11");
    sketchPortrait.style.setProperty(
      "--sketch-hair-fill",
      "radial-gradient(circle at 35% 35%, #5b3e21 0 18%, #28170d 19% 36%, transparent 37%), radial-gradient(circle at 63% 30%, #5b3e21 0 18%, #28170d 19% 36%, transparent 37%), linear-gradient(180deg, #4e3219, #24140a)"
    );
    sketchPortrait.style.setProperty("--sketch-hair-width", "34%");
    sketchPortrait.style.setProperty("--sketch-hair-height", "21%");
    sketchPortrait.style.setProperty("--sketch-hair-top", "13%");
    sketchPortrait.style.setProperty("--sketch-coat-color", "#242931");
    sketchPortrait.style.setProperty("--sketch-eye-color", "#8b6130");
    sketchPortrait.style.setProperty("--sketch-scar-opacity", "0.72");
    sketchPortrait.style.setProperty("--sketch-tattoo-opacity", "0.88");
    sketchPortrait.style.setProperty("--sketch-string-opacity", "0.64");
  }

  if (state.key === "overfit") {
    sketchPortrait.style.setProperty("--sketch-blur", "0px");
    sketchPortrait.style.setProperty("--sketch-tag-opacity", "0.95");
    sketchPortrait.style.setProperty("--sketch-noise", "0.2");
    sketchPortrait.style.setProperty(
      "--sketch-hair-fill",
      "radial-gradient(circle at 35% 35%, #5b3e21 0 18%, #28170d 19% 36%, transparent 37%), radial-gradient(circle at 63% 30%, #5b3e21 0 18%, #28170d 19% 36%, transparent 37%), linear-gradient(180deg, #4e3219, #24140a)"
    );
    sketchPortrait.style.setProperty("--sketch-hair-width", "36%");
    sketchPortrait.style.setProperty("--sketch-hair-height", "23%");
    sketchPortrait.style.setProperty("--sketch-hair-top", "12%");
    sketchPortrait.style.setProperty("--sketch-coat-color", "#242931");
    sketchPortrait.style.setProperty("--sketch-eye-color", "#8b6130");
    sketchPortrait.style.setProperty("--sketch-scar-opacity", "1");
    sketchPortrait.style.setProperty("--sketch-tattoo-opacity", "1");
    sketchPortrait.style.setProperty("--sketch-string-opacity", "1");
  }
}

function resetGuessUI(state) {
  suspectCards.forEach((card) => {
    card.classList.remove("selected", "correct", "wrong");
  });

  guessResult.className = "guess-result";
  guessResult.textContent = state.game.prompt;
}

function handleArrest(index) {
  const state = getState(Number(detailRange.value));
  const isCorrect = index === actualCriminalIndex;

  suspectCards.forEach((card) => {
    card.classList.remove("selected", "correct", "wrong");
  });

  const chosenCard = suspectCards[index];
  chosenCard.classList.add("selected", isCorrect ? "correct" : "wrong");

  if (!isCorrect) {
    suspectCards[actualCriminalIndex].classList.add("correct");
  }

  const verdict = isCorrect ? "Correct arrest." : "Wrong arrest.";
  const feedback = isCorrect ? state.game.correct : state.game.wrong;

  guessResult.className = `guess-result ${isCorrect ? "correct" : "wrong"}`;
  guessResult.innerHTML = `<strong>${verdict}</strong> ${feedback} <strong>Evidence mode:</strong> ${state.evidence} <strong>Model insight:</strong> ${state.outcome}`;

  suspectTraitTexts.forEach((textNode, suspectIndex) => {
    const score = state.confidence[suspectIndex];
    textNode.textContent = `${suspectDescriptors[suspectIndex]}. Match score: ${score}%`;
  });
}

function trainingError(x) {
  return 0.86 - 0.64 * (1 - Math.exp(-x / 24));
}

function validationError(x) {
  return 0.37 + ((x - 50) * (x - 50)) / 8600;
}

function drawCurve(ctx, graphX, graphY, padX, padY, getY, color, lineWidth) {
  ctx.strokeStyle = color;
  ctx.lineWidth = lineWidth;
  ctx.beginPath();

  for (let x = 0; x <= 100; x += 1) {
    const px = padX + (x / 100) * graphX;
    const py = padY + getY(x) * graphY;
    if (x === 0) ctx.moveTo(px, py);
    else ctx.lineTo(px, py);
  }

  ctx.stroke();
}

function drawGraphFrame(ctx, width, height, sweepRatio) {
  const padX = width * GRAPH_LAYOUT.padXRatio;
  const padY = height * GRAPH_LAYOUT.padYRatio;
  const graphX = width - padX * 2;
  const graphY = height - padY * 2;

  const bg = ctx.createLinearGradient(0, 0, width, height);
  bg.addColorStop(0, "#090909");
  bg.addColorStop(1, "#171717");
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, width, height);

  ctx.strokeStyle = "rgba(255,255,255,0.09)";
  ctx.lineWidth = 1.5;
  for (let i = 0; i <= 6; i += 1) {
    const y = padY + (i / 6) * graphY;
    ctx.beginPath();
    ctx.moveTo(padX, y);
    ctx.lineTo(width - padX, y);
    ctx.stroke();
  }
  for (let i = 0; i <= 10; i += 1) {
    const x = padX + (i / 10) * graphX;
    ctx.beginPath();
    ctx.moveTo(x, padY);
    ctx.lineTo(x, height - padY);
    ctx.stroke();
  }

  ctx.strokeStyle = "rgba(255,255,255,0.42)";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(padX, height - padY);
  ctx.lineTo(width - padX, height - padY);
  ctx.moveTo(padX, height - padY);
  ctx.lineTo(padX, padY);
  ctx.stroke();

  drawCurve(ctx, graphX, graphY, padX, padY, trainingError, "#f6ca3e", 7);
  drawCurve(ctx, graphX, graphY, padX, padY, validationError, "#f8f6ef", 6);

  const sweepX = padX + sweepRatio * graphX;
  const modelX = sweepRatio * 100;
  const trainY = padY + trainingError(modelX) * graphY;
  const validY = padY + validationError(modelX) * graphY;

  ctx.setLineDash([13, 11]);
  ctx.strokeStyle = "rgba(255, 205, 72, 0.95)";
  ctx.lineWidth = 3.2;
  ctx.beginPath();
  ctx.moveTo(sweepX, padY);
  ctx.lineTo(sweepX, height - padY);
  ctx.stroke();
  ctx.setLineDash([]);

  ctx.fillStyle = "#f6ca3e";
  ctx.beginPath();
  ctx.arc(sweepX, trainY, 8, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = "#f8f6ef";
  ctx.beginPath();
  ctx.arc(sweepX, validY, 8, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = "rgba(255,255,255,0.92)";
  ctx.font = '600 34px "DM Sans", sans-serif';
  ctx.fillText("Model Complexity", width / 2 - 120, height - 28);

  ctx.save();
  ctx.translate(40, height / 2 + 70);
  ctx.rotate(-Math.PI / 2);
  ctx.fillText("Error", 0, 0);
  ctx.restore();

  ctx.font = '600 28px "DM Sans", sans-serif';
  ctx.fillText("Training Error", width - 365, padY + 18);
  ctx.fillText("Validation Error", width - 365, padY + 60);
  ctx.fillStyle = "#f6ca3e";
  ctx.fillRect(width - 405, padY + 3, 26, 8);
  ctx.fillStyle = "#f8f6ef";
  ctx.fillRect(width - 405, padY + 45, 26, 8);
}

function pickVideoMimeType() {
  const options = ["video/webm;codecs=vp9", "video/webm;codecs=vp8", "video/webm"];
  return options.find((option) => window.MediaRecorder && MediaRecorder.isTypeSupported(option)) || "";
}

function setVideoStatus(text, hide = false) {
  if (!graphVideoStatus) return;
  graphVideoStatus.textContent = text;
  graphVideoStatus.classList.toggle("hidden", hide);
}

function updateChartMarker(value, state) {
  if (!chartMarker || !chartMarkerLabel) return;

  const min = GRAPH_LAYOUT.padXRatio * 100;
  const span = (1 - GRAPH_LAYOUT.padXRatio * 2) * 100;
  const markerLeft = min + (value / 100) * span;

  chartMarker.style.left = `${markerLeft}%`;
  chartMarker.style.backgroundColor = state.markerColor;
  chartMarker.style.boxShadow = `0 0 0 1px rgba(0,0,0,0.45), 0 0 14px ${state.markerColor}99`;

  chartMarkerLabel.textContent = `Complexity ${value}`;
  chartMarkerLabel.style.borderColor = state.markerColor;
}

function generateGraphVideo() {
  if (!graphVideo) return;

  const canRecord =
    typeof window.MediaRecorder !== "undefined" &&
    typeof HTMLCanvasElement !== "undefined" &&
    typeof HTMLCanvasElement.prototype.captureStream === "function";

  if (!canRecord) {
    setVideoStatus("Video rendering unsupported in this browser");
    return;
  }

  const mimeType = pickVideoMimeType();
  if (!mimeType) {
    setVideoStatus("No supported WebM codec found");
    return;
  }

  const renderCanvas = document.createElement("canvas");
  renderCanvas.width = 1920;
  renderCanvas.height = 1080;
  const renderCtx = renderCanvas.getContext("2d");

  drawGraphFrame(renderCtx, renderCanvas.width, renderCanvas.height, 0.4);
  graphVideo.poster = renderCanvas.toDataURL("image/png");

  const stream = renderCanvas.captureStream(30);
  const chunks = [];
  const recorder = new MediaRecorder(stream, {
    mimeType,
    videoBitsPerSecond: 12000000,
  });

  recorder.ondataavailable = (event) => {
    if (event.data && event.data.size > 0) {
      chunks.push(event.data);
    }
  };

  recorder.onerror = () => {
    setVideoStatus("Graph video render failed");
  };

  recorder.onstop = () => {
    stream.getTracks().forEach((track) => track.stop());

    if (chunks.length === 0) {
      setVideoStatus("Graph video unavailable");
      return;
    }

    const blob = new Blob(chunks, { type: mimeType });
    const url = URL.createObjectURL(blob);

    graphVideo.pause();
    graphVideo.srcObject = null;
    graphVideo.src = url;
    graphVideo.loop = true;
    graphVideo.play().catch(() => {});

    setVideoStatus("", true);
  };

  recorder.start();
  setVideoStatus("Rendering graph film...");

  graphVideo.srcObject = stream;
  graphVideo.play().catch(() => {});

  const durationMs = 6500;
  const start = performance.now();

  function render(now) {
    const t = Math.min((now - start) / durationMs, 1);
    drawGraphFrame(renderCtx, renderCanvas.width, renderCanvas.height, t);

    if (t < 1) {
      window.requestAnimationFrame(render);
    } else {
      recorder.stop();
    }
  }

  window.requestAnimationFrame(render);
}

function updateLineupScores(state) {
  confidenceBars.forEach((bar, index) => {
    const score = state.confidence[index];
    bar.style.width = `${score}%`;
    suspectTraitTexts[index].textContent = `${suspectDescriptors[index]}. Match score: ${score}%`;
  });
}

function updateUI(value) {
  const state = getState(value);
  const sceneIndex = getSceneIndexFromValue(value);
  currentSceneIndex = sceneIndex;

  document.body.dataset.phase = state.key;

  evidenceText.textContent = state.evidence;
  outcomeText.textContent = state.outcome;
  complexityTag.textContent = state.complexity;
  biasVarianceTag.textContent = state.biasVariance;
  generalizationTag.textContent = state.generalization;

  updateStoryPanel(state);
  updateSketchCard(state);
  updateLineupScores(state);
  updateChartMarker(value, state);

  if (previousStateKey !== state.key) {
    resetGuessUI(state);
    previousStateKey = state.key;
  }

  setSceneButtonState(sceneIndex);
}

sceneButtons.forEach((button, index) => {
  button.addEventListener("click", () => {
    currentSceneIndex = index;
    animateSliderTo(Number(button.dataset.target));
  });
});

scenePrev.addEventListener("click", () => {
  goToScene(currentSceneIndex - 1);
});

sceneNext.addEventListener("click", () => {
  goToScene(currentSceneIndex + 1);
});

detailRange.addEventListener("input", (event) => {
  updateUI(Number(event.target.value));
});

suspectCards.forEach((card, index) => {
  card.addEventListener("click", () => {
    handleArrest(index);
  });
});

document.addEventListener("keydown", (event) => {
  if (event.key !== "ArrowLeft" && event.key !== "ArrowRight") return;
  if (document.activeElement === detailRange) return;

  if (event.key === "ArrowLeft") {
    event.preventDefault();
    goToScene(currentSceneIndex - 1);
  }

  if (event.key === "ArrowRight") {
    event.preventDefault();
    goToScene(currentSceneIndex + 1);
  }
});

updateUI(Number(detailRange.value));
generateGraphVideo();

# Case 404: Overfitting vs Underfitting

An interactive detective-themed webpage that teaches **underfitting**, **good fit**, and **overfitting** for high school students.

## What this project includes

- Interactive witness-detail slider
- Scene-based presentation controls (Scene 1/2/3 + next/previous)
- Dynamic suspect board with changing features
- Dynamic AI terms and case metrics (bias, variance, complexity, generalization)
- Detective outcome graph as a looping HD video with a live complexity marker

## Requirements

- A modern browser (Chrome/Edge recommended for best video support)
- Python 3 (for a simple local server)

## Run locally

1. Open terminal and go to the project folder:

```bash
cd /Users/nidhisakpal/Documents/ai_visualization/overfitting
```

2. Start a local server:

```bash
python3 -m http.server 8000
```

3. Open in browser:

```
http://localhost:8000
```

4. Hard refresh once (recommended):
   - macOS: `Cmd + Shift + R`

5. Stop server when done:
   - In terminal: `Ctrl + C`

## Presentation controls

- Use **Scene 1 / Scene 2 / Scene 3** buttons for guided flow.
- Use **Previous Scene / Next Scene** for live presenting.
- Use **Left/Right arrow keys** to switch scenes.
- Drag the slider for free exploration.

## Troubleshooting

- If the graph video says unsupported:
  - Use latest Chrome or Edge.
- If updates do not appear:
  - Hard refresh the page.
- If port `8000` is busy:
  - Run `python3 -m http.server 8080` and open `http://localhost:8080`.

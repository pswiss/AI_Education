/*
K-means (Magnets & Beads) — HTML Canvas version
-----------------------------------------------
Same logic / phases as the pygame version, translated to JS Canvas.

Controls:
  SPACE  : pause/resume
  R      : reset
  N      : next phase
  +/-    : speed up / slow down
  [ / ]  : slower/faster assignment interval
  ESC    : stop animation loop
*/

const WIDTH = 1100;
const HEIGHT = 700;
const FPS = 60;

const PANEL_W = 320;
const CANVAS_W = WIDTH - PANEL_W;

const MARGIN = 40;
const BEAD_RADIUS = 7;
const MAGNET_RADIUS = 14;

const K = 3;
const N_BEADS = 26;
const ASSIGN_INTERVAL_DEFAULT = 0.25;

const DOT_RADIUS = 4;
const DOT_SPEED = 650;
const MAGNET_MOVE_SPEED = 380;

// Theme
const BG_TOP = [255, 255, 255];
const BG_BOTTOM = [246, 248, 252];
const GRID = "rgb(220, 224, 232)";
const GRID_BOLD = "rgb(206, 210, 220)";

const PANEL_BG = "rgb(255, 255, 255)";
const PANEL_LINE = "rgb(230, 234, 242)";
const TEXT = "rgb(25, 30, 40)";
const MUTED = "rgb(95, 105, 125)";
const INK = "rgb(18, 20, 26)";

const CLUSTER_COLORS = [
  [72, 140, 255],
  [255, 92, 122],
  [65, 205, 175],
  [255, 196, 86],
  [153, 102, 255],
  [255, 159, 64],
];

const PHASE_ASSIGN = "ASSIGN (one-by-one)";
const PHASE_DOTS = "DOTS → CENTER";
const PHASE_SHOW_CENTROIDS = "SHOW CENTERS";
const PHASE_ARROWS = "ARROWS (magnets → centers)";
const PHASE_MOVE = "MOVE MAGNETS";
const PHASE_DONE = "DONE (repeat)";

const PHASES = [
  PHASE_ASSIGN,
  PHASE_DOTS,
  PHASE_SHOW_CENTROIDS,
  PHASE_ARROWS,
  PHASE_MOVE,
  PHASE_DONE,
];

// -------------------------
// Helpers
// -------------------------
function clamp(v, lo, hi) {
  return Math.max(lo, Math.min(hi, v));
}

function dist(a, b) {
  return Math.hypot(a.x - b.x, a.y - b.y);
}

function meanPoint(points) {
  if (!points.length) return { x: 0, y: 0 };
  let sx = 0;
  let sy = 0;
  for (const p of points) {
    sx += p.x;
    sy += p.y;
  }
  return { x: sx / points.length, y: sy / points.length };
}

function lerp(a, b, t) {
  return a + (b - a) * t;
}

function rgb(arr) {
  return `rgb(${arr[0]}, ${arr[1]}, ${arr[2]})`;
}

function rgba(arr, a) {
  return `rgba(${arr[0]}, ${arr[1]}, ${arr[2]}, ${a})`;
}

function circle(ctx, x, y, r, fillStyle = null, strokeStyle = null, lineWidth = 1) {
  ctx.beginPath();
  ctx.arc(x, y, r, 0, Math.PI * 2);
  if (fillStyle) {
    ctx.fillStyle = fillStyle;
    ctx.fill();
  }
  if (strokeStyle) {
    ctx.lineWidth = lineWidth;
    ctx.strokeStyle = strokeStyle;
    ctx.stroke();
  }
}

function line(ctx, x1, y1, x2, y2, color, width = 1) {
  ctx.beginPath();
  ctx.moveTo(x1, y1);
  ctx.lineTo(x2, y2);
  ctx.strokeStyle = color;
  ctx.lineWidth = width;
  ctx.stroke();
}

function drawVerticalGradient(ctx, x, y, w, h, topColor, bottomColor) {
  const gradient = ctx.createLinearGradient(0, y, 0, y + h);
  gradient.addColorStop(0, rgb(topColor));
  gradient.addColorStop(1, rgb(bottomColor));
  ctx.fillStyle = gradient;
  ctx.fillRect(x, y, w, h);
}

function drawSoftGlow(ctx, x, y, colorArr, radius, alpha = 0.2) {
  ctx.save();
  ctx.shadowColor = rgba(colorArr, alpha);
  ctx.shadowBlur = radius * 2.2;
  ctx.beginPath();
  ctx.arc(x, y, Math.max(1, radius * 0.8), 0, Math.PI * 2);
  ctx.fillStyle = rgba(colorArr, Math.max(alpha, 0.001));
  ctx.fill();
  ctx.restore();
}

function drawDashedLine(ctx, color, start, end, width = 2, dashLen = 8, gapLen = 6) {
  ctx.save();
  ctx.setLineDash([dashLen, gapLen]);
  ctx.strokeStyle = color;
  ctx.lineWidth = width;
  ctx.beginPath();
  ctx.moveTo(start.x, start.y);
  ctx.lineTo(end.x, end.y);
  ctx.stroke();
  ctx.restore();
}

function drawDashedCircle(ctx, color, center, radius, width = 2, dashDeg = 18, gapDeg = 12) {
  ctx.save();
  ctx.strokeStyle = color;
  ctx.lineWidth = width;

  let a = 0;
  while (a < 360) {
    const a2 = Math.min(a + dashDeg, 360);
    ctx.beginPath();
    ctx.arc(
      center.x,
      center.y,
      radius,
      (a * Math.PI) / 180,
      (a2 * Math.PI) / 180
    );
    ctx.stroke();
    a += dashDeg + gapDeg;
  }

  ctx.restore();
}

function drawTriangleHead(ctx, color, tip, angleRad, size = 12) {
  const tx = tip.x;
  const ty = tip.y;
  const back = size;
  const spread = size * 0.55;

  const bx = tx - back * Math.cos(angleRad);
  const by = ty - back * Math.sin(angleRad);

  const left = {
    x: bx + spread * Math.cos(angleRad + Math.PI / 2),
    y: by + spread * Math.sin(angleRad + Math.PI / 2),
  };

  const right = {
    x: bx + spread * Math.cos(angleRad - Math.PI / 2),
    y: by + spread * Math.sin(angleRad - Math.PI / 2),
  };

  ctx.save();
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.moveTo(tip.x, tip.y);
  ctx.lineTo(left.x, left.y);
  ctx.lineTo(right.x, right.y);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
}

function drawDashedArrow(ctx, color, start, end, width = 3, dashLen = 10, gapLen = 8, headSize = 14) {
  drawDashedLine(ctx, color, start, end, width, dashLen, gapLen);
  const dx = end.x - start.x;
  const dy = end.y - start.y;
  const ang = Math.atan2(dy, dx);
  drawTriangleHead(ctx, color, end, ang, headSize);
}

function drawCentroidIcon(ctx, pos, colorArr, labelText = "center") {
  const x = pos.x;
  const y = pos.y;
  const ringR = 18;
  const crossLen = 10;
  const c = rgb(colorArr);

  drawSoftGlow(ctx, x, y, colorArr, 18, 0.16);
  drawDashedCircle(ctx, c, { x, y }, ringR, 3, 16, 10);

  line(ctx, x - crossLen, y, x + crossLen, y, c, 3);
  line(ctx, x, y - crossLen, x, y + crossLen, c, 3);
  circle(ctx, x, y, 4, c);

  ctx.save();
  ctx.fillStyle = c;
  ctx.font = '16px Inter, sans-serif';
  ctx.textAlign = "center";
  ctx.fillText(labelText, x, y + ringR + 22);
  ctx.restore();
}

function drawBead(ctx, x, y, colorArr, radius) {
  drawSoftGlow(ctx, x, y, colorArr, radius, 0.18);
  circle(ctx, x, y, radius, rgb(colorArr), "black", 2);
}

function drawMagnetBadge(ctx, x, y, colorArr, radius) {
  drawSoftGlow(ctx, x, y, colorArr, radius + 6, 0.14);
  circle(ctx, x, y, radius, rgb(colorArr), "black", 2);
  circle(ctx, x, y, radius - 4, null, "white", 2);

  ctx.save();
  ctx.fillStyle = "white";
  ctx.font = 'bold 14px Inter, sans-serif';
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText("M", x, y + 0.5);
  ctx.restore();
}

function drawPanelShadow(ctx, x, w, h) {
  ctx.save();
  ctx.fillStyle = "rgba(0,0,0,0.08)";
  ctx.fillRect(x - 6, 0, w, h);
  ctx.restore();
}

function randomPoint() {
  return {
    x: Math.random() * (CANVAS_W - 2 * MARGIN) + MARGIN,
    y: Math.random() * (HEIGHT - 2 * MARGIN) + MARGIN,
  };
}

// -------------------------
// Models
// -------------------------
class Bead {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.cluster = null;
    this.assigned = false;
  }
}

class Magnet {
  constructor(x, y, clusterId) {
    this.x = x;
    this.y = y;
    this.clusterId = clusterId;
  }
}

class FlyingDot {
  constructor(x, y, target, color, beadIndex, clusterId) {
    this.x = x;
    this.y = y;
    this.target = target;
    this.color = color;
    this.beadIndex = beadIndex;
    this.clusterId = clusterId;
    this.done = false;
  }
}

// -------------------------
// Main app
// -------------------------
class KMeansMagnetsBeads {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext("2d");

    this.running = true;
    this.paused = false;

    this.assignInterval = ASSIGN_INTERVAL_DEFAULT;
    this.speedMult = 1.0;

    this.iteration = 1;
    this.phaseIndex = 0;

    this.beads = [];
    this.magnets = [];
    this.centroids = [];
    this.flying = [];

    this.assignOrder = [];
    this.assignCursor = 0;
    this.assignTimer = 0.0;

    this.centroidTimer = 0.0;
    this.arrowsTimer = 0.0;

    this.doneTimer = 0.0;
    this.doneConverged = false;

    this.decor = this.makeDecor();

    this.bindEvents();
    this.resetWorld();
  }

  makeDecor() {
    const items = [];
    const rng = mulberry32(12345);

    for (let i = 0; i < 16; i++) {
      const x = rng() * CANVAS_W;
      const y = rng() * HEIGHT;
      const r = 16 + rng() * (52 - 16);
      const a = Math.floor(8 + rng() * (22 - 8));
      items.push({ x, y, r, color: `rgba(210,220,245,${a / 255})` });
    }
    return items;
  }

  setPhase(name) {
    this.phaseIndex = PHASES.indexOf(name);
  }

  phase() {
    return PHASES[this.phaseIndex];
  }

  resetWorld() {
    this.phaseIndex = 0;
    this.iteration = 1;
    this.doneTimer = 0.0;
    this.doneConverged = false;

    this.beads = [];
    for (let i = 0; i < N_BEADS; i++) {
      const p = randomPoint();
      this.beads.push(new Bead(p.x, p.y));
    }

    this.magnets = [];
    for (let cid = 0; cid < K; cid++) {
      const p = randomPoint();
      this.magnets.push(new Magnet(p.x, p.y, cid));
    }

    this.startAssignmentPhase();
  }

  startAssignmentPhase() {
    this.setPhase(PHASE_ASSIGN);

    for (const b of this.beads) {
      b.cluster = null;
      b.assigned = false;
    }

    const dists = [];
    for (let i = 0; i < this.beads.length; i++) {
      const b = this.beads[i];
      let best = Infinity;
      for (const m of this.magnets) {
        best = Math.min(best, dist(b, m));
      }
      dists.push([best, i]);
    }

    dists.sort((a, b) => a[0] - b[0]);
    this.assignOrder = dists.map((entry) => entry[1]);

    this.assignCursor = 0;
    this.assignTimer = 0.0;
    this.flying = [];
    this.centroids = [];
  }

  computeAssignmentsFull() {
    for (let i = 0; i < this.beads.length; i++) {
      this.assignBead(i);
    }
  }

  assignBead(beadIndex) {
    const b = this.beads[beadIndex];
    let bestCid = null;
    let bestD = Infinity;

    for (const m of this.magnets) {
      const d = dist(b, m);
      if (d < bestD) {
        bestD = d;
        bestCid = m.clusterId;
      }
    }

    b.cluster = bestCid;
    b.assigned = true;
  }

  computeCentroids() {
    const centroids = [];

    for (let cid = 0; cid < K; cid++) {
      const pts = this.beads
        .filter((b) => b.cluster === cid)
        .map((b) => ({ x: b.x, y: b.y }));

      if (pts.length) {
        centroids.push(meanPoint(pts));
      } else {
        const m = this.magnets[cid];
        centroids.push({ x: m.x, y: m.y });
      }
    }

    return centroids;
  }

  startDotsPhase() {
    this.setPhase(PHASE_DOTS);
    this.flying = [];
    this.centroids = this.computeCentroids();

    for (let i = 0; i < this.beads.length; i++) {
      const b = this.beads[i];
      if (b.cluster === null) continue;

      const cid = b.cluster;
      const cpos = this.centroids[cid];
      const col = CLUSTER_COLORS[cid % CLUSTER_COLORS.length];

      this.flying.push(new FlyingDot(b.x, b.y, cpos, col, i, cid));
    }
  }

  startShowCentroidsPhase() {
    this.setPhase(PHASE_SHOW_CENTROIDS);
    this.centroidTimer = 0.0;
  }

  startArrowsPhase() {
    this.setPhase(PHASE_ARROWS);
    this.arrowsTimer = 0.0;
  }

  startMovePhase() {
    this.setPhase(PHASE_MOVE);
  }

  startDonePhase() {
    this.setPhase(PHASE_DONE);
    this.doneTimer = 0.0;
  }

  restartIteration() {
    this.iteration += 1;
    this.startAssignmentPhase();
  }

  update(dt) {
    if (this.paused || !this.running) return;

    dt *= this.speedMult;
    const phase = this.phase();

    if (phase === PHASE_ASSIGN) {
      this.assignTimer += dt;

      if (
        this.assignCursor < this.assignOrder.length &&
        this.assignTimer >= this.assignInterval
      ) {
        this.assignTimer -= this.assignInterval;
        const idx = this.assignOrder[this.assignCursor];
        this.assignBead(idx);
        this.assignCursor += 1;
      }

      if (this.assignCursor >= this.assignOrder.length) {
        this.startDotsPhase();
      }
    } else if (phase === PHASE_DOTS) {
      let allDone = true;

      for (const dot of this.flying) {
        if (dot.done) continue;
        allDone = false;

        const tx = dot.target.x;
        const ty = dot.target.y;
        const dx = tx - dot.x;
        const dy = ty - dot.y;
        const d = Math.hypot(dx, dy);
        const step = DOT_SPEED * dt;

        if (d <= step || d < 1e-6) {
          dot.x = tx;
          dot.y = ty;
          dot.done = true;
        } else {
          dot.x += (dx / d) * step;
          dot.y += (dy / d) * step;
        }
      }

      if (allDone) {
        this.startShowCentroidsPhase();
      }
    } else if (phase === PHASE_SHOW_CENTROIDS) {
      this.centroidTimer += dt;
      if (this.centroidTimer >= 0.8) {
        this.startArrowsPhase();
      }
    } else if (phase === PHASE_ARROWS) {
      this.arrowsTimer += dt;
      if (this.arrowsTimer >= 0.9) {
        this.startMovePhase();
      }
    } else if (phase === PHASE_MOVE) {
      let movedAll = true;

      for (const m of this.magnets) {
        const target = this.centroids[m.clusterId];
        const dx = target.x - m.x;
        const dy = target.y - m.y;
        const d = Math.hypot(dx, dy);
        const step = MAGNET_MOVE_SPEED * dt;

        if (d <= step || d < 1e-6) {
          m.x = target.x;
          m.y = target.y;
        } else {
          movedAll = false;
          m.x += (dx / d) * step;
          m.y += (dy / d) * step;
        }
      }

      if (movedAll) {
        let converged = true;
        const newCentroids = this.computeCentroids();

        for (let cid = 0; cid < K; cid++) {
          if (dist(this.magnets[cid], newCentroids[cid]) > 0.75) {
            converged = false;
            break;
          }
        }

        this.doneConverged = converged;
        this.startDonePhase();
      }
    } else if (phase === PHASE_DONE) {
      this.doneTimer += dt;
      if (this.doneTimer >= 1.2) {
        this.doneTimer = 0.0;
        if (this.doneConverged || this.iteration >= 10) {
          // stay in done state
        } else {
          this.restartIteration();
        }
      }
    }
  }

  draw() {
    const ctx = this.ctx;

    ctx.clearRect(0, 0, WIDTH, HEIGHT);

    drawVerticalGradient(ctx, 0, 0, CANVAS_W, HEIGHT, BG_TOP, BG_BOTTOM);
    this.drawDecor(ctx);
    this.drawGrid(ctx);

    drawPanelShadow(ctx, CANVAS_W, PANEL_W, HEIGHT);
    ctx.fillStyle = PANEL_BG;
    ctx.fillRect(CANVAS_W, 0, PANEL_W, HEIGHT);
    line(ctx, CANVAS_W, 0, CANVAS_W, HEIGHT, PANEL_LINE, 2);

    const phase = this.phase();

    if (phase === PHASE_ASSIGN && this.assignCursor < this.assignOrder.length) {
      const idx = this.assignOrder[this.assignCursor];
      const b = this.beads[idx];

      for (const m of this.magnets) {
        line(ctx, b.x, b.y, m.x, m.y, "rgb(170, 175, 190)", 1);
      }

      let nearest = this.magnets[0];
      let nearestD = dist(b, nearest);
      for (const m of this.magnets.slice(1)) {
        const d = dist(b, m);
        if (d < nearestD) {
          nearest = m;
          nearestD = d;
        }
      }

      const col = rgb(CLUSTER_COLORS[nearest.clusterId % CLUSTER_COLORS.length]);
      line(ctx, b.x, b.y, nearest.x, nearest.y, col, 3);
    }

    if (phase === PHASE_ARROWS) {
      for (const m of this.magnets) {
        const cid = m.clusterId;
        const col = rgb(CLUSTER_COLORS[cid % CLUSTER_COLORS.length]);
        drawDashedArrow(ctx, col, { x: m.x, y: m.y }, this.centroids[cid], 3, 10, 8, 14);
      }
    }

    for (const b of this.beads) {
      const col = b.cluster === null
        ? [170, 175, 190]
        : CLUSTER_COLORS[b.cluster % CLUSTER_COLORS.length];
      drawBead(ctx, b.x, b.y, col, BEAD_RADIUS);
    }

    if (phase === PHASE_DOTS) {
      for (const dot of this.flying) {
        drawSoftGlow(ctx, dot.x, dot.y, dot.color, DOT_RADIUS + 2, 0.16);
        circle(ctx, dot.x, dot.y, DOT_RADIUS, rgb(dot.color), "black", 1);
      }
    }

    if ([PHASE_SHOW_CENTROIDS, PHASE_ARROWS, PHASE_MOVE, PHASE_DONE].includes(phase)) {
      for (let cid = 0; cid < K; cid++) {
        drawCentroidIcon(ctx, this.centroids[cid], CLUSTER_COLORS[cid % CLUSTER_COLORS.length], "center");
      }
    }

    for (const m of this.magnets) {
      const col = CLUSTER_COLORS[m.clusterId % CLUSTER_COLORS.length];
      drawMagnetBadge(ctx, m.x, m.y, col, MAGNET_RADIUS);
    }

    this.drawPanel(ctx);
  }

  drawDecor(ctx) {
    ctx.save();
    for (const item of this.decor) {
      ctx.fillStyle = item.color;
      ctx.beginPath();
      ctx.arc(item.x, item.y, item.r, 0, Math.PI * 2);
      ctx.fill();
    }

    const rng = mulberry32(777);
    for (let i = 0; i < 24; i++) {
      const x = rng() * CANVAS_W;
      const y = rng() * HEIGHT;
      const a = 18 + rng() * (35 - 18);
      const col = `rgba(190,200,220,${a / 255})`;
      line(ctx, x - 6, y, x + 6, y, col, 2);
      line(ctx, x, y - 6, x, y + 6, col, 2);
    }
    ctx.restore();
  }

  drawGrid(ctx) {
    const step = 40;
    const boldEvery = 5;

    for (let i = 0, x = 0; x < CANVAS_W; i++, x += step) {
      line(ctx, x, 0, x, HEIGHT, i % boldEvery === 0 ? GRID_BOLD : GRID, 1);
    }

    for (let j = 0, y = 0; y < HEIGHT; j++, y += step) {
      line(ctx, 0, y, CANVAS_W, y, j % boldEvery === 0 ? GRID_BOLD : GRID, 1);
    }

    ctx.save();
    ctx.strokeStyle = GRID_BOLD;
    ctx.lineWidth = 2;
    ctx.strokeRect(0, 0, CANVAS_W, HEIGHT);
    ctx.restore();
  }

  drawPanel(ctx) {
    const x0 = CANVAS_W + 18;
    let y = 34;

    ctx.save();

    ctx.fillStyle = TEXT;
    ctx.font = 'bold 24px Inter, sans-serif';
    ctx.fillText("K-means: Magnets & Beads", x0, y);

    y += 40;
    ctx.font = '18px Inter, sans-serif';
    ctx.fillStyle = TEXT;
    ctx.fillText(`Phase: ${this.phase()}`, x0, y);

    y += 28;
    ctx.fillStyle = MUTED;
    ctx.fillText(`Iteration: ${this.iteration}`, x0, y);

    y += 28;
    const assigned = this.beads.filter((b) => b.assigned).length;
    ctx.fillText(`Assigned: ${assigned}/${this.beads.length}`, x0, y);

    y += 28;
    ctx.fillText(`Speed: ${this.speedMult.toFixed(2)}x`, x0, y);

    y += 28;
    ctx.fillText(`Assign interval: ${this.assignInterval.toFixed(2)}s`, x0, y);

    y += 34;

    const lines = [
      "1) ASSIGN:",
      "   Each bead picks the",
      "   nearest magnet.",
      "",
      "2) CENTER:",
      "   Beads vote a center",
      "   (the mean position).",
      "",
      "3) UPDATE:",
      "   Magnets move to the",
      "   center.",
      "",
      "Repeat until stable.",
    ];

    ctx.font = '15px Inter, sans-serif';
    for (const text of lines) {
      ctx.fillStyle = text && /^\d/.test(text) ? TEXT : MUTED;
      ctx.fillText(text, x0, y);
      y += 20;
    }

    y += 10;
    line(ctx, CANVAS_W + 18, y, WIDTH - 18, y, PANEL_LINE, 1);
    y += 18;

    const controls = [
      "Controls:",
      "SPACE  pause/resume",
      "R      reset",
      "N      next phase",
      "+/-    speed",
      "[ / ]  assignment speed",
      "ESC    stop",
    ];

    for (const text of controls) {
      ctx.fillStyle = MUTED;
      ctx.fillText(text, x0, y);
      y += 20;
    }

    if (this.phase() === PHASE_DONE) {
      y += 12;
      ctx.font = '18px Inter, sans-serif';
      ctx.fillStyle = TEXT;
      ctx.fillText(
        this.doneConverged ? "Converged ✅" : "Not converged yet…",
        x0,
        y
      );
    }

    ctx.restore();
  }

  bindEvents() {
    window.addEventListener("keydown", (event) => {
      if (event.code === "Escape") {
        this.running = false;
      } else if (event.code === "Space") {
        event.preventDefault();
        this.paused = !this.paused;
      } else if (event.key === "r" || event.key === "R") {
        this.resetWorld();
      } else if (event.key === "n" || event.key === "N") {
        this.manualNextPhase();
      } else if (event.key === "+" || event.key === "=") {
        this.speedMult = clamp(this.speedMult + 0.25, 0.25, 4.0);
      } else if (event.key === "-") {
        this.speedMult = clamp(this.speedMult - 0.25, 0.25, 4.0);
      } else if (event.key === "[") {
        this.assignInterval = clamp(this.assignInterval + 0.05, 0.05, 1.0);
      } else if (event.key === "]") {
        this.assignInterval = clamp(this.assignInterval - 0.05, 0.05, 1.0);
      }
    });
  }

  manualNextPhase() {
    const phase = this.phase();

    if (phase === PHASE_ASSIGN) {
      this.computeAssignmentsFull();
      this.assignCursor = this.assignOrder.length;
      this.startDotsPhase();
    } else if (phase === PHASE_DOTS) {
      for (const dot of this.flying) {
        dot.x = dot.target.x;
        dot.y = dot.target.y;
        dot.done = true;
      }
      this.startShowCentroidsPhase();
    } else if (phase === PHASE_SHOW_CENTROIDS) {
      this.startArrowsPhase();
    } else if (phase === PHASE_ARROWS) {
      this.startMovePhase();
    } else if (phase === PHASE_MOVE) {
      for (const m of this.magnets) {
        const t = this.centroids[m.clusterId];
        m.x = t.x;
        m.y = t.y;
      }
      this.doneConverged = true;
      this.startDonePhase();
    } else if (phase === PHASE_DONE) {
      this.restartIteration();
    }
  }
}

// -------------------------
// deterministic tiny RNG
// -------------------------
function mulberry32(seed) {
  let t = seed >>> 0;
  return function () {
    t += 0x6D2B79F5;
    let x = Math.imul(t ^ (t >>> 15), 1 | t);
    x ^= x + Math.imul(x ^ (x >>> 7), 61 | x);
    return ((x ^ (x >>> 14)) >>> 0) / 4294967296;
  };
}

// -------------------------
// Boot
// -------------------------
const canvas = document.getElementById("kmeansCanvas");
const app = new KMeansMagnetsBeads(canvas);

let lastTime = performance.now();

function loop(now) {
  const dt = Math.min((now - lastTime) / 1000, 1 / 20);
  lastTime = now;

  app.update(dt);
  app.draw();

  if (app.running) {
    requestAnimationFrame(loop);
  }
}

requestAnimationFrame(loop);